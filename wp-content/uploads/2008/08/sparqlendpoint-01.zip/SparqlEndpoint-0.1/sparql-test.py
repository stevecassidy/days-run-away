# simple test of sparql endpoint using Ivan Herman's SPARQL wrapper

from SPARQL import SPARQLWrapper

sparql = SPARQLWrapper("http://localhost:8012/sparql")

# query on default graph
print "Query 1"
sparql.setQuery("SELECT ?t WHERE { ?s <http://purl.org/rss/1.0/title> ?t. }")
for line in sparql.query():
    print line,

# add a default graph - a google news search for 'rdf'
sparql.addDefaultGraph("http://news.google.com/news?q=rdf&output=rss")

# find titles of things
print "\n\nQuery 2"
sparql.setQuery("SELECT ?t WHERE { ?s <http://purl.org/rss/1.0/title> ?t. }")
for line in sparql.query():
    print line,
    
    
