from distutils.core import setup
setup(name="SparqlEndpoint",
      version="0.1",
	  description="SPARQL endpoint for Redland via WSGI",
	  author="Steve Cassidy",
	  author_email="Steve.Cassidy@mq.edu.au",
	  maintainer="Steve Cassidy",
	  maintainer_email="Steve.Cassidy@mq.edu.au",
	  packages=["SparqlEndpoint"],
	  url="http://www.comp.mq.edu.au/~cassidy/", 
	  )


